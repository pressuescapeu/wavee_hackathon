package com.example.wavee_first_try

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
